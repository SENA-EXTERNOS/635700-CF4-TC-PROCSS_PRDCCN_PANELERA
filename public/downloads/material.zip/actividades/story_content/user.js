function ExecuteScript(strId)
{
  switch (strId)
  {
      case "67TQyFR1zoK":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

