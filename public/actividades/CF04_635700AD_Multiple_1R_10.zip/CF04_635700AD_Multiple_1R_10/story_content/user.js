function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6iz4D5cXfa3":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

